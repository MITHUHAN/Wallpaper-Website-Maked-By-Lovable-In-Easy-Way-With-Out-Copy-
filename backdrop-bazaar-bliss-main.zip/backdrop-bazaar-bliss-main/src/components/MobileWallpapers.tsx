
import React, { useState } from 'react';
import { Download, Heart, Share2 } from 'lucide-react';

interface MobileWallpapersProps {
  onNavigate: (page: 'welcome' | 'desktop') => void;
}

const MobileWallpapers: React.FC<MobileWallpapersProps> = ({ onNavigate }) => {
  const [likedWallpapers, setLikedWallpapers] = useState<Set<number>>(new Set());

  // Mock wallpaper data - in a real app, this would come from an API
  const wallpapers = [
    { id: 1, title: "Ocean Waves", category: "Nature", url: "https://images.unsplash.com/photo-1505142468610-359e7d316be0?w=400&h=800&fit=crop" },
    { id: 2, title: "City Lights", category: "Urban", url: "https://images.unsplash.com/photo-1519501025264-65ba15a82390?w=400&h=800&fit=crop" },
    { id: 3, title: "Mountain Peak", category: "Nature", url: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=800&fit=crop" },
    { id: 4, title: "Abstract Art", category: "Abstract", url: "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=400&h=800&fit=crop" },
    { id: 5, title: "Forest Path", category: "Nature", url: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=400&h=800&fit=crop" },
    { id: 6, title: "Neon Vibes", category: "Digital", url: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=800&fit=crop" },
    { id: 7, title: "Sunset Sky", category: "Nature", url: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=800&fit=crop" },
    { id: 8, title: "Geometric", category: "Abstract", url: "https://images.unsplash.com/photo-1557683316-973673baf926?w=400&h=800&fit=crop" }
  ];

  const handleLike = (id: number) => {
    setLikedWallpapers(prev => {
      const newLiked = new Set(prev);
      if (newLiked.has(id)) {
        newLiked.delete(id);
      } else {
        newLiked.add(id);
      }
      return newLiked;
    });
  };

  const handleDownload = (wallpaper: any) => {
    // In a real app, this would trigger an actual download
    console.log(`Downloading: ${wallpaper.title}`);
    // For demo purposes, we'll just open the image in a new tab
    window.open(wallpaper.url, '_blank');
  };

  return (
    <div className="min-h-screen py-20 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-7xl font-bold text-gradient mb-6">
            Mobile Wallpapers
          </h1>
          <p className="text-xl text-white/80">
            Perfect for your smartphone screen
          </p>
        </div>

        {/* Wallpaper Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {wallpapers.map((wallpaper) => (
            <div key={wallpaper.id} className="wallpaper-card aspect-[9/16]">
              <img
                src={wallpaper.url}
                alt={wallpaper.title}
                className="w-full h-full object-cover"
                loading="lazy"
              />
              
              {/* Overlay */}
              <div className="wallpaper-overlay">
                <div className="flex flex-col items-center gap-4">
                  <h3 className="text-white font-semibold text-lg">
                    {wallpaper.title}
                  </h3>
                  <div className="flex gap-3">
                    <button
                      onClick={() => handleLike(wallpaper.id)}
                      className={`p-3 rounded-full glass-effect transition-all duration-300 ${
                        likedWallpapers.has(wallpaper.id) 
                          ? 'text-red-400 bg-red-400/20' 
                          : 'text-white hover:bg-white/20'
                      }`}
                    >
                      <Heart 
                        className={`w-5 h-5 ${
                          likedWallpapers.has(wallpaper.id) ? 'fill-current' : ''
                        }`} 
                      />
                    </button>
                    <button
                      onClick={() => handleDownload(wallpaper)}
                      className="p-3 rounded-full glass-effect text-white hover:bg-white/20 transition-all duration-300"
                    >
                      <Download className="w-5 h-5" />
                    </button>
                    <button className="p-3 rounded-full glass-effect text-white hover:bg-white/20 transition-all duration-300">
                      <Share2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Category badge */}
              <div className="absolute top-4 left-4 z-30">
                <span className="px-3 py-1 text-xs font-medium rounded-full glass-effect text-white">
                  {wallpaper.category}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Navigation to Desktop */}
        <div className="text-center mt-16">
          <button
            onClick={() => onNavigate('desktop')}
            className="button-hero"
          >
            Browse Desktop Wallpapers
          </button>
        </div>
      </div>
    </div>
  );
};

export default MobileWallpapers;
