
import React, { useEffect, useState } from 'react';
import { Smartphone, Monitor, Download } from 'lucide-react';

interface WelcomeSceneProps {
  onNavigate: (page: 'mobile' | 'desktop') => void;
}

const WelcomeScene: React.FC<WelcomeSceneProps> = ({ onNavigate }) => {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center relative hero-gradient">
      {/* Floating elements */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 6}s`,
              animationDuration: `${6 + Math.random() * 6}s`
            }}
          >
            <div className="w-2 h-2 rounded-full primary-gradient animate-glow" />
          </div>
        ))}
      </div>

      {/* Main content */}
      <div 
        className={`text-center z-20 transition-all duration-1000 ${
          isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}
      >
        {/* Logo/Title */}
        <div className="mb-8">
          <h1 className="text-7xl md:text-9xl font-bold text-gradient mb-4 animate-pulse-slow">
            WALLPAPERS
          </h1>
          <p className="text-xl md:text-2xl text-white/80 font-light">
            Discover stunning wallpapers for every device
          </p>
        </div>

        {/* Download icon */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-24 h-24 glass-effect rounded-full animate-glow">
            <Download className="w-12 h-12 text-primary" />
          </div>
        </div>

        {/* Navigation buttons */}
        <div className="flex flex-col md:flex-row gap-6 justify-center items-center">
          <button
            onClick={() => onNavigate('mobile')}
            className="button-hero group"
          >
            <div className="flex items-center gap-4">
              <Smartphone className="w-6 h-6 group-hover:rotate-12 transition-transform duration-300" />
              <span>Mobile Wallpapers</span>
            </div>
          </button>

          <button
            onClick={() => onNavigate('desktop')}
            className="button-hero group"
          >
            <div className="flex items-center gap-4">
              <Monitor className="w-6 h-6 group-hover:scale-110 transition-transform duration-300" />
              <span>Desktop Wallpapers</span>
            </div>
          </button>
        </div>

        {/* Subtitle */}
        <p className="mt-8 text-white/60 text-lg">
          Choose your platform to explore our collection
        </p>
      </div>
    </div>
  );
};

export default WelcomeScene;
