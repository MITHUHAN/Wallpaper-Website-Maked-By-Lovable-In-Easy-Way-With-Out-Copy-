
import React, { useState, useEffect } from 'react';
import WelcomeScene from '../components/WelcomeScene';
import MobileWallpapers from '../components/MobileWallpapers';
import DesktopWallpapers from '../components/DesktopWallpapers';

type PageState = 'welcome' | 'mobile' | 'desktop';

const Index = () => {
  const [currentPage, setCurrentPage] = useState<PageState>('welcome');
  const [isTransitioning, setIsTransitioning] = useState(false);

  const navigateToPage = (page: PageState) => {
    setIsTransitioning(true);
    setTimeout(() => {
      setCurrentPage(page);
      setIsTransitioning(false);
    }, 300);
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'welcome':
        return <WelcomeScene onNavigate={navigateToPage} />;
      case 'mobile':
        return <MobileWallpapers onNavigate={navigateToPage} />;
      case 'desktop':
        return <DesktopWallpapers onNavigate={navigateToPage} />;
      default:
        return <WelcomeScene onNavigate={navigateToPage} />;
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background particles */}
      <div className="fixed inset-0 z-0">
        {[...Array(50)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-primary rounded-full animate-pulse-slow"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 4}s`,
              animationDuration: `${4 + Math.random() * 4}s`
            }}
          />
        ))}
      </div>

      {/* Page content */}
      <div 
        className={`relative z-10 transition-all duration-300 ${
          isTransitioning ? 'opacity-0 scale-95' : 'opacity-100 scale-100'
        }`}
      >
        {renderCurrentPage()}
      </div>

      {/* Navigation overlay for non-welcome pages */}
      {currentPage !== 'welcome' && (
        <div className="fixed top-6 left-6 z-50">
          <button
            onClick={() => navigateToPage('welcome')}
            className="glass-effect px-6 py-3 rounded-2xl text-white hover:bg-white/10 transition-all duration-300"
          >
            ← Back to Home
          </button>
        </div>
      )}
    </div>
  );
};

export default Index;
